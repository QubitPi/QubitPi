'use strict'

module.exports = (obj) => console.log({ obj }) && obj
