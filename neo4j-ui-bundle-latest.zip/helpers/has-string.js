'use strict'

module.exports = (hay, needle) => hay.indexOf(needle) > -1
