'use strict'

module.exports = (value, joiner) => value.split(joiner)
